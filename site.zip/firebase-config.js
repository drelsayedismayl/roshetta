/* املأ البيانات دي من Firebase (الشرح في README). لو فاضية، زر الحساب بيفضل مخفي. */
window.FIREBASE_CONFIG = { apiKey:"", authDomain:"", projectId:"", messagingSenderId:"", appId:"" };
window.FCM_VAPID_KEY = "";
