#!/usr/bin/env python3
"""يفحص ملف data/content.json قبل ما ترفعه: python tools/validate.py"""
import json,sys,os
root=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
p=os.path.join(root,'data','content.json')
try:C=json.load(open(p,encoding='utf-8'))
except Exception as e:
    print('❌ الملف فيه خطأ في الصياغة (غالبًا فاصلة ناقصة أو زيادة):',e);sys.exit(1)
errs=[]
def chk(name,cond,msg):
    if not cond:errs.append(f'{name}: {msg}')
for i,lv in enumerate(C['QB']):
    for j,x in enumerate(lv):chk('QB',isinstance(x,list) and len(x)==5,f'المستوى {i+1} سؤال رقم {j+1} لازم يكون 5 عناصر (السؤال + الإجابة الصح + 3 غلط)')
for i,t in enumerate(C['TIPS']):chk('TIPS',len(t)==2,f'نصيحة رقم {i+1} لازم [القسم, النص]')
pg=C['PGDATA']
chk('PGDATA',len(pg['PG'])==len(pg['PGI']),'عدد المنتجات لازم يساوي عدد الصور')
for p_ in pg['PGI']:chk('PGDATA',os.path.exists(os.path.join(root,p_)),f'صورة ناقصة: {p_}')
for o in C['OT']:chk('OT',os.path.exists(os.path.join(root,o[3])),f'صورة ناقصة: {o[3]}')
if errs:
    print('❌ في مشاكل:');[print(' -',e) for e in errs[:30]];sys.exit(1)
print('✅ الملف سليم')
