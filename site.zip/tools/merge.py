#!/usr/bin/env python3
"""يدمج updates/extra.json في content.json. الاستخدام: merge.py content.json extra.json"""
import json,sys,os
c,e=sys.argv[1],sys.argv[2]
if not os.path.exists(e): print('no extra.json, skipping');sys.exit(0)
try: X=json.load(open(e,encoding='utf-8'))
except Exception as ex: print('::error::ملف extra.json فيه خطأ في الكتابة (غالبًا فاصلة أو علامة تنصيص ناقصة):',ex);sys.exit(1)
C=json.load(open(c,encoding='utf-8'))
for k,v in X.items():
    if k.startswith('_'):continue
    if k=='QB':
        for i,lv in enumerate(v[:5]):
            if lv: C['QB'][i]=C['QB'][i]+lv
    elif isinstance(v,dict): C.setdefault(k,{}).update(v)
    elif isinstance(v,list): C[k]=C.get(k,[])+v
    else: C[k]=v
if X.get('UP'): C['UP']=sorted(C['UP'],key=lambda r:r[0],reverse=True) if False else C['UP']
json.dump(C,open(c,'w',encoding='utf-8'),ensure_ascii=False)
print('merged keys:',[k for k in X if not k.startswith('_')])
