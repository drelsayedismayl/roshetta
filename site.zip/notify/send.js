// يبعت نصيحة دوائية لكل الأجهزة المسجلة. بيتشغل من GitHub Actions.
const admin=require('firebase-admin'),fs=require('fs');
admin.initializeApp({credential:admin.credential.cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT))});
(async()=>{
const C=JSON.parse(fs.readFileSync('content.json','utf8'));const h=Math.floor(Date.now()/36e5);let title,body,image;
if(h%2===0){const t=C.TIPS[Math.floor(h/2)%C.TIPS.length];title='💊 معلومة دوائية: '+t[0];body=t[1]}else{const d=C.DB[Math.floor(h/2)%C.DB.length];title='💊 '+d[0];body=d[1]+': '+d[2];if(d[4])image=process.env.SITE_URL+d[4]}
const db=admin.firestore(),snap=await db.collection('tokens').get();
const tokens=snap.docs.map(d=>d.id);console.log('tokens',tokens.length);
for(let i=0;i<tokens.length;i+=500){
 const chunk=tokens.slice(i,i+500);
 const r=await admin.messaging().sendEachForMulticast({tokens:chunk,notification:Object.assign({title,body:body.slice(0,180)},image?{image}:{}),webpush:{fcmOptions:{link:process.env.SITE_URL}}});
 await Promise.all(r.responses.map((x,j)=>(!x.success&&/not-registered|invalid-argument|invalid-registration/.test(x.error.code))?db.collection('tokens').doc(chunk[j]).delete():0));
 console.log('sent',r.successCount,'failed',r.failureCount);
}})().catch(e=>{console.error(e);process.exit(1)});
