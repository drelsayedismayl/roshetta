/* عارض الصور (معاينة الكتب وتكبير الملخصات) */
window.__viewer=function(list,title,dl,full){var o=document.createElement('div');o.style.cssText='position:fixed;inset:0;z-index:80;background:rgba(0,0,0,.85);display:flex;flex-direction:column;direction:rtl';
var h=document.createElement('div');h.style.cssText='display:flex;gap:8px;align-items:center;padding:10px 12px;padding-top:calc(10px + env(safe-area-inset-top,0px));color:#fff';
var t=document.createElement('b');t.textContent=title||'';t.style.flex='1';h.appendChild(t);
function btn(x,hr){var a=document.createElement('a');a.textContent=x;a.href=hr;a.target='_blank';a.rel='noopener';a.style.cssText='background:#fff;color:#111;border-radius:8px;padding:6px 10px;text-decoration:none;font-size:.85rem';h.appendChild(a)}
if(dl)btn('⬇ تحميل الكامل',dl);var c=document.createElement('button');c.textContent='✕';c.style.cssText='background:none;border:0;color:#fff;font-size:1.4rem;cursor:pointer';c.onclick=function(){o.remove()};h.appendChild(c);
var b=document.createElement('div');b.style.cssText='flex:1;overflow:auto;padding:8px;text-align:center';(list||[]).forEach(function(s){var i=document.createElement('img');i.src=s;i.loading='lazy';i.style.cssText='max-width:100%;display:block;margin:0 auto 10px;border-radius:8px;background:#fff';b.appendChild(i)});
if(list&&list.length>1){var n=document.createElement('p');n.style.cssText='color:#ddd;font-size:.85rem';n.textContent='دي معاينة أول صفحات الكتاب. للنسخة الكاملة اضغط تحميل.';b.appendChild(n)}
o.appendChild(h);o.appendChild(b);document.body.appendChild(o)};
/* دليل الأدوية بالصور - بيقرأ C.DB من content.json */
(function(){try{
var DB=(window.C&&C.DB)||[];if(!DB.length||typeof go!=='function')return;
function el(t,c,x){var e=document.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;return e}
var p=el('section','panel');p.id='p-meds';var w=el('div','in');w.style.justifyContent='flex-start';p.appendChild(w);
w.appendChild(el('h2','','💊 دليل الأدوية'));w.appendChild(el('p','sub',DB.length+' مادة وعلامة تجارية بالصور. ابحث بالاسم التجاري أو المادة الفعالة'));
var q=document.createElement('input');q.type='search';q.placeholder='ابحث: Voltaren، ميتفورمين، ضغط...';q.style.cssText='width:100%;padding:11px 14px;border:1.5px solid var(--line);border-radius:12px;background:var(--card);color:var(--ink);font:inherit;margin:6px 0 10px;direction:ltr;text-align:right';w.appendChild(q);
var cats=[];DB.forEach(function(d){if(cats.indexOf(d[3])<0)cats.push(d[3])});var cur='All',cc=el('div','chips'),g=el('div','gg');g.style.gridTemplateColumns='repeat(auto-fill,minmax(150px,1fr))';
function chip(l,v){var b=el('button','chip'+(v==='All'?' on':''),l);b.onclick=function(){cur=v;cc.querySelectorAll('.chip').forEach(function(z){z.classList.remove('on')});b.classList.add('on');r()};cc.appendChild(b)}
chip('الكل','All');cats.forEach(function(c){chip(c,c)});w.appendChild(cc);w.appendChild(g);
function r(){g.innerHTML='';var s=q.value.trim().toLowerCase(),n=0;
DB.forEach(function(d){if(cur!=='All'&&d[3]!==cur)return;if(s&&(d[0]+' '+d[1]+' '+d[2]).toLowerCase().indexOf(s)<0)return;if(n++>=60)return;
var sl=d.length>5;var c=el('div','gcard');if(sl){c.style.gridColumn='span 2';var i0=document.createElement('img');i0.src=d[4];i0.alt=d[0];i0.loading='lazy';i0.style.cssText='width:100%;border-radius:10px;cursor:zoom-in;background:#fff';i0.onclick=function(){window.__viewer([d[4]],d[0])};c.appendChild(i0);c.appendChild(el('small','','ملخص · '+d[3]));var b0=el('b','',d[0]);b0.style.direction='ltr';c.appendChild(b0);g.appendChild(c);return}if(d[4]){var i=document.createElement('img');i.src=d[4];i.alt=d[0];i.loading='lazy';i.style.cssText='width:100%;height:110px;object-fit:contain;background:#fff;border-radius:10px';c.appendChild(i)}
c.appendChild(el('small','',d[3]));var b=el('b','',d[0]);b.style.direction='ltr';c.appendChild(b);var a=el('p','dnote',d[1]);a.style.cssText='direction:ltr;margin:2px 0';c.appendChild(a);c.appendChild(el('p','',d[2]));g.appendChild(c)});
if(!n)g.appendChild(el('p','sub','مفيش نتيجة. جرّب اسم تاني.'))}
q.oninput=r;r();document.querySelector('main').appendChild(p);
if(P.indexOf('meds')<0)P.push('meds');
var t=el('button','tab');t.dataset.p='meds';t.innerHTML='<span>💊</span>الأدوية';t.onclick=function(){go('meds')};
var ref=document.querySelector('.tab[data-p="quiz"]');ref.parentNode.insertBefore(t,ref);
}catch(e){}})();
