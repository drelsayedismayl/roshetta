# روشتة | د. السيد إسماعيل
الخطوات الكاملة في دليل النشر (المستند اللي بعتهولك). مختصر: ارفع site.zip في repo اسمه roshetta، وأنشئ .github/workflows/build.yml من ملف build.yml، وفعّل Settings → Pages → GitHub Actions.
بعد ربط Firebase (firebase-config.js + سر FIREBASE_SERVICE_ACCOUNT) بتشتغل الإشعارات (6 يوميًا) والتسجيل. firestore.rules للصقه في Firestore Rules.
