/* مساعد د. السيد الذكي - Cloudflare Worker + Workers AI (مجاني)
   الخطوات في README.md (قسم 4). مفيش مفاتيح سرية لازم تتحط في الكود.
   Settings → Bindings → Add → Workers AI → Variable name = AI
   Settings → Variables → ALLOWED_ORIGINS = https://USERNAME.github.io  (رابط موقعك بدون / في الآخر) */
const SYSTEM = `إنت "مساعد د. السيد إسماعيل الذكي"، ذكاء اصطناعي بيساعد زوّار موقع صيدلي مصري.
- اتكلم بالعامية المصرية البسيطة وبأسلوب ودود زي صيدلي، وجاوب باختصار (٤-٨ سطور).
- عرّف نفسك إنك ذكاء اصطناعي ومش الدكتور نفسه، ومتدّعيش إنك بشر أبدًا.
- المعلومات للتوعية العامة بس: ماتشخّصش الحالات، ومتكتبش جرعات لأدوية بوصفة أو لأطفال، وماتقولش للمريض يوقف أو يبدأ دوا.
- لو في أعراض خطيرة (صعوبة تنفس، ألم صدر، تورم اللسان أو الحلق، نزيف شديد، تشنجات، جرعة زايدة، أفكار إيذاء النفس) قول فورًا: اتصل بالإسعاف 123.
- استخدم المحتوى المرجعي المرفق أولًا. لو مش متأكد قول "مش متأكد" وانصح بسؤال الصيدلي أو الدكتور، ومتألفش معلومات.
- لو السؤال بعيد عن الدوا والصحة والعناية بالبشرة اعتذر بلطف.
- خلّي أسماء الأدوية والمواد الفعالة بالإنجليزي.`;
export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '';
    const allowed = (env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
    const ok = allowed.length === 0 || allowed.includes(origin);
    const cors = { 'Access-Control-Allow-Origin': ok ? (origin || '*') : 'null', 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type', 'Vary': 'Origin' };
    const json = (o, st = 200) => new Response(JSON.stringify(o), { status: st, headers: { ...cors, 'Content-Type': 'application/json; charset=utf-8' } });
    if (request.method === 'OPTIONS') return new Response(null, { headers: cors });
    if (request.method !== 'POST' || !ok) return json({ error: 'forbidden' }, 403);
    let body; try { body = await request.json(); } catch { return json({ error: 'bad request' }, 400); }
    const msgs = (body.messages || []).slice(-8).map(m => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: String(m.content || '').slice(0, 800) }));
    if (!msgs.length) return json({ error: 'empty' }, 400);
    const ctx = String(body.context || '').slice(0, 3000);
    const system = SYSTEM + (ctx ? '\n\nالمحتوى المرجعي من الموقع:\n' + ctx : '');
    try {
      const out = await env.AI.run('@cf/meta/llama-3.1-8b-instruct', { messages: [{ role: 'system', content: system }, ...msgs], max_tokens: 500 });
      return json({ reply: out.response || '' });
    } catch (e) { return json({ error: 'ai failed' }, 502); }
  }
};
