/* بديل: Google Gemini (خطة مجانية، العربي فيها أحسن غالبًا).
   محتاج مفتاح من https://aistudio.google.com/apikey ويتحط في Worker: Settings → Variables and Secrets → GEMINI_KEY (Secret).
   ALLOWED_ORIGINS زي النسخة التانية.
   ملاحظة خصوصية: في الخطة المجانية جوجل ممكن تستخدم المحادثات لتحسين منتجاتها. اسم الموديل ممكن يتغيّر، شوف القائمة الحالية في موقع جوجل. */
const MODEL = 'gemini-2.0-flash';
const SYSTEM = `إنت "مساعد د. السيد إسماعيل الذكي"، ذكاء اصطناعي بيساعد زوّار موقع صيدلي مصري.
- اتكلم بالعامية المصرية البسيطة وبأسلوب ودود، وجاوب باختصار (٤-٨ سطور).
- عرّف نفسك إنك ذكاء اصطناعي ومش الدكتور نفسه.
- للتوعية العامة بس: ماتشخّصش، ومتكتبش جرعات لأدوية بوصفة أو لأطفال، وماتقولش للمريض يوقف أو يبدأ دوا.
- لو أعراض خطيرة (صعوبة تنفس، ألم صدر، تورم اللسان أو الحلق، نزيف شديد، تشنجات، جرعة زايدة، أفكار إيذاء النفس) قول: اتصل بالإسعاف 123 فورًا.
- استخدم المحتوى المرجعي أولًا ومتألفش معلومات. لو مش متأكد قول كده.
- أسماء الأدوية بالإنجليزي. لو السؤال بعيد عن الصحة والدوا والبشرة اعتذر بلطف.`;
export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '';
    const allowed = (env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
    const ok = allowed.length === 0 || allowed.includes(origin);
    const cors = { 'Access-Control-Allow-Origin': ok ? (origin || '*') : 'null', 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type', 'Vary': 'Origin' };
    const json = (o, st = 200) => new Response(JSON.stringify(o), { status: st, headers: { ...cors, 'Content-Type': 'application/json; charset=utf-8' } });
    if (request.method === 'OPTIONS') return new Response(null, { headers: cors });
    if (request.method !== 'POST' || !ok) return json({ error: 'forbidden' }, 403);
    let body; try { body = await request.json(); } catch { return json({ error: 'bad request' }, 400); }
    const msgs = (body.messages || []).slice(-8).map(m => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: String(m.content || '').slice(0, 800) }] }));
    if (!msgs.length) return json({ error: 'empty' }, 400);
    const ctx = String(body.context || '').slice(0, 3000);
    const system = SYSTEM + (ctx ? '\n\nالمحتوى المرجعي من الموقع:\n' + ctx : '');
    try {
      const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`, {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': env.GEMINI_KEY },
        body: JSON.stringify({ systemInstruction: { parts: [{ text: system }] }, contents: msgs, generationConfig: { maxOutputTokens: 500 } })
      });
      const j = await r.json();
      return json({ reply: j.candidates?.[0]?.content?.parts?.[0]?.text || '' });
    } catch (e) { return json({ error: 'ai failed' }, 502); }
  }
};
